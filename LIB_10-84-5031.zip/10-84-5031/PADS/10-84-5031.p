*PADS-LIBRARY-PART-TYPES-V9*

10-84-5031 SHDR3W166P0X635_1X3_2032X762X1397P I CON 7 1 0 0 0
TIMESTAMP 2026.08.01.19.48.42
"Mouser Part Number" 538-10-84-5031
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Molex/10-84-5031?qs=SeTnVz%252B%252BFGCWr%2FNErglIpQ%3D%3D
"Manufacturer_Name" Molex
"Manufacturer_Part_Number" 10-84-5031
"Description" Pin & Socket Connectors
"Datasheet Link" https://www.molex.com/pdm_docs/sd/010845031_sd.pdf
"Geometry.Height" 13.97mm
GATE 1 3 0
10-84-5031
1 0 U 1
2 0 U 2
3 0 U 3

*END*
*REMARK* SamacSys ECAD Model
523718/2125552/2.50/3/4/Connector
